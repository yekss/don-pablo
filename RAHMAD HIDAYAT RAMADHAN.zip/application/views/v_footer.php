<footer id="fh5co-footer" role="contentinfo">

		<div class="container">
			<div class="col-md-3 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>About Me</h3>
				<p>Saya suka melalukan perjalanan menuju alam lalu mengabadikannya melalui kamera dan setiap moment sangat berharga dan harus diabadikan </p>
			</div>
			<div class="col-md-6 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Sisi lain saya</h3>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">Travelling</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Fotographer</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Designer</li>
					<li><a href="<?php echo base_url().'portfolio'?>">Riding</a></li>
				</ul>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">Enterprenaur</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Businesst Man</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Online Marketing</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Graphic Design</a></li>
				</ul>

			</div>

			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Follow Me</h3>
				<ul class="fh5co-social">
					<li><a href="http://facebook.com/Rahmad Hidayat"><i class="icon-facebook"></i></a></li>

					<li><a href="http://instagram.com/rahmadhidayt15"><i class="icon-instagram"></i></a></li>
				</ul>
			</div>


			<div class="col-md-12 fh5co-copyright text-center">
				<p>&copy; 2020 by <a href="http://instagram.com/rahmadhidayt15" target="_blank">Dayat Ramadhan</a>. All Rights Reserved.</p>
			</div>

		</div>
	</footer>
